from django.apps import AppConfig


class ChannelsAppConfig(AppConfig):
    name = 'chat.channels_app'
