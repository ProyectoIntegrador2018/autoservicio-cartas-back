# -*- coding: utf-8 -*-
from __future__ import unicode_literals, absolute_import

from chat.core.models.user import User
from chat.core.models.message import Message
